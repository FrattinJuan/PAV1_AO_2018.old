﻿Public Class Criticidad
    Public Property id_criticidad As Integer
    Public Property nombre As String
End Class
