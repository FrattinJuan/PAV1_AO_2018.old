﻿Public Class Prioridad
    Public Property id_prioridad As Integer
    Public Property nombre As String
End Class
