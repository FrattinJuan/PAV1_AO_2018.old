﻿Public Class Usuario
    Public Property nombre As String
    Public Property password As String
    Public Property email As String
    Public Property estado As String
    Public Property id_usuario As Integer
    'Relación con Perfil
    Public Property id_perfil As String
    Public Property perfil As String
End Class
